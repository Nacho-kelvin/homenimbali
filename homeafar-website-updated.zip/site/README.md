# HomeAFar website (Vite + React + Supabase)

Photos in `public/images/homeafar` are named for what they show (e.g. `passport-picnic-group-five-800.webp`); each exists in several widths. Their captions live in `src/content.js` (`PH`).

## Run locally
```
npm install
cp .env.example .env     # fill in the two public values
npm run dev
```
## Environment variables (Vercel > Project > Settings > Environment Variables)
- `VITE_SUPABASE_URL` – your Supabase project URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` – the publishable (anon) key. Safe for the browser because Row Level Security protects the data.
- Never add a `service_role` key or database password to this project.

## Database
1. Supabase > SQL editor: run `supabase/schema.sql`.
2. Authentication > Users > Add user (the founder's email + password).
3. Run the commented `insert into admins ...` line at the bottom of the schema to make that user an owner.
4. Sign in at `/admin`.

## Deploy to Vercel
Import the repo; framework "Vite" is auto-detected (build `npm run build`, output `dist`). `vercel.json` makes clean URLs work.

## Admin guide
`/admin` > **Submissions**: read, mark reviewed, archive or delete contact, volunteer, partner, membership, newsletter and event-registration entries. **Events / Opportunities**: add (saved as draft), then Publish or Unpublish. Opportunities need a source link; set an expiry date and they disappear automatically.

## Images
Illustrative still-life photos (`kente-weave`, `travel-flatlay`, `coffee-pot-beans`, `textiles-fabrics`, `notebook-plant`, `armchair-home`, and the four `gen-*` AI-generated images) are decorative only. Never use them to represent real HomeAFar events or people. Side-panel images are captioned "Illustrative image".

## Editing copy
Stats, journey timeline, FAQ, footer links and page content are in `src/content.js`. Only add figures that can be verified.

## Not built yet (future work)
Stories and country-profile publishing from the dashboard, team profiles, partner listings, email notifications/confirmations, CAPTCHA, scheduling, French content, event photo galleries (waiting on approved photos), analytics, donations/ticketing (deliberately not started), Charles's approved bio, Gloria's approved bio and photo.
