import { useEffect } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import { Header, Footer, BackToTop } from './components.jsx'
import * as P from './pages.jsx'
import Admin from './Admin.jsx'

function useReveal() {
  const { pathname } = useLocation()
  useEffect(() => {
    if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return
    document.documentElement.classList.add('js')
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target) } }), { threshold: 0.08 })
    const t = setTimeout(() => document.querySelectorAll('.sec').forEach((el) => io.observe(el)), 50)
    return () => { clearTimeout(t); io.disconnect() }
  }, [pathname])
}

export default function App() {
  useReveal()
  return (<>
    <Header />
    <main id="main">
      <Routes>
        <Route path="/" element={<P.Home />} />
        <Route path="/about" element={<P.About />} />
        {['safe-landing', 'tourism-to-africa', 'protection-and-justice'].map((s) => <Route key={s} path={`/${s}`} element={<P.ContentPage slug={s} />} />)}
        <Route path="/womens-health" element={<P.ContentPage slug="womens-health" />} />
        <Route path="/events" element={<P.Events />} />
        <Route path="/stories-from-afar" element={<P.Stories />} />
        <Route path="/beyond-the-borders" element={<P.Beyond />} />
        <Route path="/opportunities" element={<P.Opportunities />} />
        <Route path="/get-involved" element={<P.GetInvolved />} />
        <Route path="/contact" element={<P.Contact />} />
        <Route path="/privacy" element={<P.Privacy />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<P.NotFound />} />
      </Routes>
    </main>
    <Footer />
    <BackToTop />
  </>)
}
