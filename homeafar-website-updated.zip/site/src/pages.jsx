import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Hero, Notice, Form, Gallery, Photo, Figure, Stats, Journey, Faq, usePage } from './components.jsx'
import { FOUNDERS, SECTORS, COUNTRIES, VALUES, PAGES, GALLERY, FAQ, TOPICS, OPP_TYPES, NAV } from './content.js'
import { supabase, backendReady } from './lib/supabase.js'

const fmt = (d) => new Date(d + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
const today = () => new Date().toISOString().slice(0, 10)
const IG = 'https://www.instagram.com/home.a.far/'
const TILE_SIZES = '(min-width:1000px) 270px, (min-width:700px) 45vw, 92vw'
const SECTOR_IMG = { '/safe-landing': 'traveler', '/tourism-to-africa': 'gTravel', '/protection-and-justice': 'hands', '/womens-health': 'roots' }

const TILE3_SIZES = '(min-width:1200px) 380px, (min-width:900px) 31vw, (min-width:560px) 46vw, 92vw'
const MediaTile = ({ to, img, title, children, sizes = TILE_SIZES }) => (
  <Link to={to} className="tile media"><Photo name={img} sizes={sizes} /><div className="tb"><h3>{title}</h3><p>{children}</p><span className="more" aria-hidden="true">Learn more →</span></div></Link>
)

export function Home() {
  usePage('Home', 'HomeAFar connects Africans across borders through community, cultural exchange, storytelling, events and practical opportunities.')
  return (<>
    <Hero title="Home is wherever we find Each Other." lead="HomeAFar is an African-founded community and impact initiative connecting Africans across borders — starting from African experiences in Romania and Eastern Europe." img="desk" mobile="traveler">
      <div className="btn-row"><Link className="btn" to="/get-involved">Get involved</Link><Link className="btn ghost light" to="/about">Our story</Link></div>
    </Hero>
    <Stats />
    <section className="wrap sec"><span className="eyebrow">What we do</span><h2>What HomeAFar does</h2>
      <p className="measure">We bring people together through community gatherings, cultural exchange and storytelling, and we are building practical pathways to belonging and opportunity.</p>
      <div className="grid4">{SECTORS.map(([to, t, d]) => <MediaTile key={to} to={to} img={SECTOR_IMG[to]} title={t}>{d}</MediaTile>)}</div></section>
    <section className="wrap sec alt"><span className="eyebrow">Community</span><h2>Ways to connect</h2>
      <div className="grid3">
        <MediaTile to="/events" img="pp3" title="Events" sizes={TILE3_SIZES}>Our first community event, Passport Picnic, took place on 30 August 2026.</MediaTile>
        <MediaTile to="/stories-from-afar" img="notebook" title="Stories From Afar" sizes={TILE3_SIZES}>The experiences of Africans living abroad, shared with consent.</MediaTile>
        <MediaTile to="/beyond-the-borders" img="gCulture" title="Beyond the Borders" sizes={TILE3_SIZES}>A series celebrating Africa's diversity, country by country.</MediaTile>
      </div></section>
    <section className="wrap sec dark"><div className="split"><Photo name="pp1" sizes="(min-width:700px) 50vw, 92vw" className="rounded" />
      <div><span className="eyebrow">Our first event</span><h2>Passport Picnic</h2><p className="meta">30 August 2026 · Tineretului Park, Bucharest</p><p>Our first community event, a cultural potluck with games bringing together participants connected to Kenya, the Republic of the Congo, Rwanda, Senegal and Zambia.</p><Link className="btn" to="/events">See the event</Link></div></div></section>
    <section className="wrap sec"><span className="eyebrow">Our journey</span><h2>From one move to a growing community</h2><Journey /></section>
    <section className="wrap sec cta green"><span className="eyebrow">Join us</span><h2>Be part of it</h2><p>Join as a member, volunteer, or partner with us, and follow along for what comes next.</p>
      <div className="btn-row center"><Link className="btn" to="/get-involved">Get involved</Link><a className="btn ghost light" href={IG} target="_blank" rel="noreferrer">Follow on Instagram</a></div></section>
  </>)
}

export function About() {
  usePage('About', 'The story, mission, vision and values of HomeAFar, founded by Gloria Murugi Njiru.')
  return (<>
    <Hero title="About HomeAFar" lead="Home is not only a place on a map. It can be the people who welcome us." img="hands" />
    <section className="wrap sec"><div className="split top"><div><span className="eyebrow">Our story</span><h2>Where HomeAFar began</h2>
      <p>HomeAFar was inspired by the journey of its founder, Gloria Murugi Njiru, a Kenyan woman who moved to Romania in November 2024. Starting over in another country can bring possibility, and it can also bring unfamiliar systems, cultural adjustment and loneliness. She came to believe that home is also the belonging we create with others.</p>
      <p>HomeAFar is an evolving journey. Not every planned programme is operating yet.</p></div>
      <Photo name="team" sizes="(min-width:700px) 50vw, 92vw" className="rounded" /></div></section>
    <section className="wrap sec alt"><div className="grid2 flush">
      <div className="tile"><span className="eyebrow">Mission</span><p>To strengthen African presence and connection in Eastern Europe through community, economic opportunities, events and cultural exchange, while building a platform for advocacy, practical support and meaningful social impact.</p></div>
      <div className="tile"><span className="eyebrow">Vision</span><p>To grow into a trusted, internationally connected African community organisation that helps people move from merely surviving abroad to thriving with dignity, connection, opportunity and access to support.</p></div></div></section>
    <section className="wrap sec"><span className="eyebrow">What guides us</span><h2>Values</h2><div className="grid4">{VALUES.map(([t, d]) => <div className="tile" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div></section>
    <section className="wrap sec dark"><div className="split top"><div><span className="eyebrow">The people</span><h2>Founders</h2>
      <div className="stack">{FOUNDERS.map(([n, r, d]) => <div className="tile" key={n}><h3>{n}</h3><p className="role">{r}</p><p>{d}</p></div>)}</div></div>
      <Photo name="pp2" sizes="(min-width:700px) 50vw, 92vw" className="rounded" /></div></section>
    <section className="wrap sec"><span className="eyebrow">Our journey</span><h2>How we got here</h2><Journey /></section>
    <section className="wrap sec cta green"><h2>Help us build it</h2><p>Members, volunteers and partners shape what HomeAFar becomes.</p><div className="btn-row center"><Link className="btn" to="/get-involved">Get involved</Link><Link className="btn ghost light" to="/contact">Contact us</Link></div></section>
  </>)
}

export function ContentPage({ slug }) {
  const p = PAGES[slug]
  usePage(p.title, p.lead)
  const related = (p.related || []).map((to) => NAV.find(([t]) => t === to)).filter(Boolean)
  return (<>
    <Hero title={p.title} lead={p.lead} img={p.img} />
    <section className="wrap sec"><div className="page-grid">
      <div className="measure"><Notice>{p.notice}</Notice>
        {p.sections.map(([h, body, list]) => <div key={h}><h2>{h}</h2>
          {list ? <ul>{body.map((b) => <li key={b}>{b}</li>)}</ul> : body.map((b) => <p key={b}>{b}</p>)}</div>)}
      </div>
      <aside className="side">
        {p.side && <Figure name={p.side} sizes="(min-width:1000px) 360px, 92vw" caption="Illustrative image" />}
        <div className="tile"><h3>Have a question?</h3><p>Tell us what you most need to know and we will point you in the right direction.</p><Link className="btn" to="/contact">Ask us a question</Link></div>
        {related.length > 0 && <div className="tile"><h3>Also explore</h3><ul className="links">{related.map(([to, l]) => <li key={to}><Link to={to}>{l}</Link></li>)}</ul></div>}
      </aside></div></section>
    {p.gallery && <section className="wrap sec alt"><span className="eyebrow">Coming to this page</span><h2>What we will explore</h2>
      <div className="grid4 figs">{p.gallery.map(([n, c]) => <Figure key={n} name={n} caption={c} sizes={TILE_SIZES} className="card" />)}</div></section>}
  </>)
}

function useRows(table, order) {
  const [s, setS] = useState({ rows: [], loading: true, error: false })
  useEffect(() => {
    if (!backendReady) return setS({ rows: [], loading: false, error: false })
    supabase.from(table).select('*').order(order).then(({ data, error }) => setS({ rows: data || [], loading: false, error: !!error }))
  }, [table, order])
  return s
}

export function Events() {
  usePage('Events', 'Upcoming and past HomeAFar community events, including Passport Picnic.')
  const { rows, loading, error } = useRows('events', 'starts_on')
  const [reg, setReg] = useState(null)
  const upcoming = rows.filter((e) => e.starts_on >= today())
  const past = rows.filter((e) => e.starts_on < today()).reverse()
  return (<>
    <Hero title="Events" lead="Moments to meet, share culture, play and feel included." img="pp2" mobile="desk" pos="center 35%" />
    <section className="wrap sec"><span className="eyebrow">What's next</span><h2>Upcoming events</h2>
      {loading && <p>Loading events…</p>}
      {error && <p role="alert">We could not load events right now. Please try again later.</p>}
      {!loading && !error && upcoming.length === 0 && <div className="split top"><div className="tile"><h3>No upcoming events are announced yet</h3><p>We would love you to be first to know when the next gathering is planned.</p></div>
        <div className="tile"><h3>Hear first</h3><Form kind="newsletter" askName={false} askMessage={false} button="Subscribe" done="You are subscribed. Thank you." /></div></div>}
      {upcoming.map((e) => <article className="tile wide" key={e.id}><h3>{e.title}</h3><p className="meta">{fmt(e.starts_on)}{e.location && ` · ${e.location}`}</p><p>{e.description}</p>
        <div className="btn-row">{e.ticket_url && <a className="btn" href={e.ticket_url} rel="noreferrer" target="_blank">Tickets</a>}
          {e.registration_open && <button className="btn ghost" onClick={() => setReg(reg === e.id ? null : e.id)}>Register</button>}</div>
        {reg === e.id && <Form kind="event_registration" eventId={e.id} askMessage={false} button="Register" done="You are registered. Thank you." />}
      </article>)}</section>
    <section className="wrap sec alt"><span className="eyebrow">Look back</span><h2>Past events</h2>
      <div className="split top"><div><article className="tile"><h3>Passport Picnic</h3><p className="meta">30 August 2026 · Tineretului Park, Bucharest</p>
        <p>A cultural potluck with games, bringing together participants connected to Kenya, the Republic of the Congo, Rwanda, Senegal and Zambia.</p></article>
        {past.map((e) => <article className="tile wide" key={e.id}><h3>{e.title}</h3><p className="meta">{fmt(e.starts_on)}{e.location && ` · ${e.location}`}</p><p>{e.description}</p></article>)}</div>
        <Photo name="poster" sizes="(min-width:700px) 480px, 92vw" className="rounded poster" /></div>
      <Gallery names={GALLERY} label="Passport Picnic photographs" /></section></>)
}

export function Stories() {
  usePage('Stories From Afar', 'Stories of Africans living abroad: belonging, loneliness, identity and growth.')
  return (<><Hero title="Stories From Afar" lead="Belonging, cultural adjustment, loneliness, identity and personal growth." img="armchair" pos="center 60%" />
    <section className="wrap sec"><div className="split top"><div><Notice>Stories are published only with the storyteller's consent. English and French versions, captions and transcripts will be offered where available.</Notice>
      <h2>Share yours</h2><p>No stories are published yet. If you would like to share yours, tell us a little about it and we will contact you.</p>
      <p>We are looking for stories about:</p><div className="chips">{['Belonging', 'Cultural adjustment', 'Loneliness', 'Identity', 'Personal growth'].map((c) => <span key={c}>{c}</span>)}</div></div>
      <div className="tile"><Form kind="contact" categories={['Share my story']} messageLabel="A short summary (no private details yet)" button="Share interest" /></div></div></section></>)
}

export function Beyond() {
  usePage('Beyond the Borders', 'A country and culture series celebrating the diversity of Africa.')
  return (<><Hero title="Beyond the Borders" lead="Africa's diversity, country by country: culture, history, languages, food, music, fashion, tourism, economy and contemporary life." img="gCulture" />
    <section className="wrap sec"><div className="split top"><div><Notice>Country profiles are in preparation and will be published only after their facts are checked against credible sources.</Notice>
      <h2>What every profile will cover</h2><div className="chips">{TOPICS.map((c) => <span key={c}>{c}</span>)}</div></div>
      <Photo name="gFood" sizes="(min-width:700px) 50vw, 92vw" className="rounded" /></div></section>
    <section className="wrap sec alt"><span className="eyebrow">The series</span><h2>First countries</h2>
      <div className="grid4">{COUNTRIES.map(([n, d]) => <div className="tile" key={n}><h3>{n}</h3><p>{d || 'Profile coming soon.'}</p><span className="badge">Coming soon</span></div>)}</div></section></>)
}

export function Opportunities() {
  usePage('Opportunities', 'Verified scholarships, jobs, internships, volunteering, training and business opportunities.')
  const { rows, loading, error } = useRows('opportunities', 'expires_on')
  const [cat, setCat] = useState('All')
  const cats = ['All', ...new Set(rows.map((r) => r.category).filter(Boolean))]
  const shown = cat === 'All' ? rows : rows.filter((r) => r.category === cat)
  return (<><Hero title="Opportunities" lead="Scholarships, jobs, internships, volunteering, training, business and creative collaborations." img="gGrowth" />
    <section className="wrap sec"><Notice>Every listing shows its source and an expiry date where relevant.</Notice>
      {loading && <p>Loading opportunities…</p>}
      {error && <p role="alert">We could not load opportunities right now.</p>}
      {!loading && !error && rows.length === 0 && <div className="split top"><div><h2>No verified opportunities are listed yet</h2><p>When we publish them, you will find these kinds of opportunity here:</p>
        <div className="chips">{OPP_TYPES.map((c) => <span key={c}>{c}</span>)}</div>
        <p><Link className="btn" to="/get-involved">Subscribe for updates</Link></p></div>
        <div className="tile"><h3>How we check listings</h3><ol className="steps"><li>Each one needs a source link you can open yourself.</li><li>A closing date is shown wherever there is one.</li><li>It stays a draft until we have checked it.</li></ol></div></div>}
      {rows.length > 0 && <div className="tabs" role="group" aria-label="Filter by category">{cats.map((c) => <button key={c} aria-pressed={cat === c} onClick={() => setCat(c)}>{c}</button>)}</div>}
      <div className="grid2 flush">{shown.map((o) => <article className="tile" key={o.id}><h3>{o.title}</h3><p className="muted">{o.category}{o.expires_on && ` · Closes ${fmt(o.expires_on)}`}</p><p>{o.description}</p>
        <a href={o.source_url} target="_blank" rel="noreferrer">View source</a></article>)}</div></section></>)
}

const WaysTile = ({ id, title, blurb, children }) => <div className="tile formtile" id={id}><h3>{title}</h3><p>{blurb}</p>{children}</div>

export function GetInvolved() {
  usePage('Get Involved', 'Become a member, volunteer, partner with HomeAFar or subscribe to updates.')
  return (<><Hero title="Get Involved" lead="Choose the way that suits you." img="pp1" mobile="desk" pos="center 40%" />
    <section className="wrap sec"><nav className="chips jump" aria-label="Ways to get involved"><a href="#member">Become a member</a><a href="#volunteer">Volunteer</a><a href="#partner">Partner with us</a><a href="#subscribe">Subscribe</a></nav><div className="grid-forms">
      <WaysTile id="member" title="Become a member" blurb="Join the community and be part of what we build together."><Form kind="membership" askMessage={false} button="Express interest" done="Thank you. We will be in touch about membership." /></WaysTile>
      <WaysTile id="volunteer" title="Volunteer" blurb="Lend your time and skills to events, content and community care."><Form kind="volunteer" messageLabel="How would you like to help?" button="Apply" done="Thank you. We will review your application." /></WaysTile>
      <WaysTile id="partner" title="Partner with us" blurb="Organisations, businesses and creators: let us explore working together."><Form kind="partner" messageLabel="About your organisation and idea" button="Send inquiry" /></WaysTile></div></section>
    <section className="wrap sec green" id="subscribe"><div className="split"><div><span className="eyebrow">Stay in the loop</span><h2>Subscribe to updates</h2><p>Be first to hear about events, stories and opportunities. No spam, and you can ask us to remove your details at any time.</p></div>
      <div className="tile"><Form kind="newsletter" askName={false} askMessage={false} button="Subscribe" done="You are subscribed. Thank you." /></div></div></section>
    <Faq items={FAQ} />
  </>)
}

export function Contact() {
  usePage('Contact', 'Contact HomeAFar by form, email, Instagram or Facebook.')
  return (<><Hero title="Contact" lead="We would love to hear from you." img="team" mobile="traveler" pos="center 40%" />
    <section className="wrap sec"><div className="split top"><div><div className="contact-list">
      <a className="tile ccard" href="mailto:homeafar26@gmail.com"><span className="eyebrow">Email</span><strong>homeafar26@gmail.com</strong></a>
      <a className="tile ccard" href={IG} target="_blank" rel="noreferrer"><span className="eyebrow">Instagram</span><strong>@home.a.far</strong></a>
      <div className="tile ccard"><span className="eyebrow">Facebook</span><strong>Home AFar</strong></div></div>
      <Notice>Please do not include medical details or detailed accounts of incidents in this form.</Notice></div>
      <div className="tile"><Form kind="contact" categories={['General question', 'Events', 'Safe Landing', 'Protection & Justice', 'Partnerships', 'Media']} /></div></div></section>
    <Faq items={[FAQ[1], FAQ[3], FAQ[5]]} title="Before you write" />
  </>)
}

export function Privacy() {
  usePage('Privacy', 'How HomeAFar uses the details you send through its forms.')
  return (<section className="wrap sec measure"><h1>Privacy notice</h1>
    <p>We collect only what you type into our forms: your name, email address, message and your choice of topic. We use it only to reply to you, handle your application or registration, or send updates you asked for.</p>
    <p>Submissions are stored securely and are visible only to authorised HomeAFar administrators. You can ask us to export or delete your details at any time by emailing <a href="mailto:homeafar26@gmail.com">homeafar26@gmail.com</a>.</p>
    <p>Please do not send sensitive medical information through our forms.</p></section>)
}

export const NotFound = () => { usePage('Page not found'); return <section className="wrap sec notfound"><span className="eyebrow">Error 404</span><h1>Page not found</h1><p>That page does not exist or has moved. Try one of these instead:</p>
  <div className="chips">{[['/', 'Home'], ['/about', 'About'], ['/events', 'Events'], ['/get-involved', 'Get involved'], ['/contact', 'Contact']].map(([to, l]) => <Link key={to} to={to}>{l}</Link>)}</div></section> }
