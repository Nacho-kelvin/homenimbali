import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { NAV, PH, FAQ, STATS, JOURNEY, FOOTER_NAV } from './content.js'
import { supabase, backendReady } from './lib/supabase.js'

export function usePage(title, description) {
  useEffect(() => {
    document.title = title === 'Home' ? 'HomeAFar — Home is wherever we find Each Other' : `${title} — HomeAFar`
    const m = document.querySelector('meta[name="description"]')
    if (m && description) m.setAttribute('content', description)
    window.scrollTo(0, 0)
  }, [title, description])
}

export function Header() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  useEffect(() => setOpen(false), [pathname])
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    const onResize = () => window.innerWidth >= 1200 && setOpen(false)
    window.addEventListener('keydown', onKey); window.addEventListener('resize', onResize)
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('resize', onResize); document.body.style.overflow = '' }
  }, [open])
  return (
    <header className="header">
      <a className="skip" href="#main">Skip to content</a>
      <Link to="/" className="brand" onClick={() => setOpen(false)}>
        <img src="/images/homeafar/homeafar-logo.png" alt="" width="44" height="44" /><span>HomeAFar</span>
      </Link>
      <button className="burger" aria-expanded={open} aria-controls="menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(!open)}>
        <span /><span /><span />
      </button>
      <nav id="menu" className={open ? 'menu open' : 'menu'} aria-label="Main">
        {NAV.map(([to, label, short]) => <NavLink key={to} to={to} onClick={() => setOpen(false)}><span className="f">{label}</span><span className="s">{short || label}</span></NavLink>)}
      </nav>
    </header>
  )
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="wrap foot-grid">
        <div className="foot-brand">
          <Link to="/" className="brand"><img src="/images/homeafar/homeafar-logo.png" alt="" width="40" height="40" /><span>HomeAFar</span></Link>
          <p>Home is wherever we find Each Other.</p>
          <p className="foot-links-inline">
            <a href="mailto:homeafar26@gmail.com">homeafar26@gmail.com</a>
            <a href="https://www.instagram.com/home.a.far/" target="_blank" rel="noreferrer">Instagram @home.a.far</a>
            <span>Facebook: Home AFar</span>
          </p>
        </div>
        {Object.entries(FOOTER_NAV).map(([h, links]) => (
          <nav key={h} aria-label={h}><h2 className="foot-h">{h}</h2>
            <ul>{links.map(([to, l]) => <li key={to}><Link to={to}>{l}</Link></li>)}</ul></nav>
        ))}
      </div>
      <div className="wrap foot-base"><span>© {new Date().getFullYear()} HomeAFar. All rights reserved.</span><span>Founded by Gloria Murugi Njiru</span></div>
    </footer>
  )
}

export function BackToTop() {
  const [show, setShow] = useState(false)
  useEffect(() => {
    const on = () => setShow(window.scrollY > 700)
    on(); window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  return <button type="button" className={show ? 'totop show' : 'totop'} aria-label="Back to top" tabIndex={show ? 0 : -1} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>↑</button>
}

export function Faq({ items = FAQ, title = 'Questions people ask', eyebrow = 'FAQ' }) {
  return (
    <section className="wrap sec"><span className="eyebrow">{eyebrow}</span><h2>{title}</h2>
      <div className="faq">{items.map(([q, a]) => (
        <details key={q}><summary>{q}</summary><p>{a.includes('privacy notice') ? <>{a.replace(' Read the privacy notice for details.', '')} <Link to="/privacy">Read the privacy notice.</Link></> : a}</p></details>
      ))}</div>
    </section>
  )
}

export function Stats() {
  return (
    <section className="statband" aria-label="HomeAFar at a glance">
      <ul className="wrap stats">{STATS.map(([n, l, d]) => <li key={l}><b>{n}</b><span>{l}</span><small>{d}</small></li>)}</ul>
    </section>
  )
}

export function Journey() {
  return (
    <ol className="journey">{JOURNEY.map(([when, t, d]) => (
      <li key={when}><span className="when">{when}</span><h3>{t}</h3><p>{d}</p></li>
    ))}</ol>
  )
}

const src = (p, w) => `/images/homeafar/${p.b}-${w}.webp`
const srcSet = (p) => p.w.map((w) => `${src(p, w)} ${w}w`).join(', ')

export function Photo({ name, sizes = '(min-width:1000px) 360px, 90vw', className, ...rest }) {
  const p = PH[name]
  return <img className={className} src={src(p, p.w[1] || p.w[0])} srcSet={srcSet(p)} sizes={sizes} alt={p.alt} loading="lazy" decoding="async" {...rest} />
}

export function Figure({ name, caption, sizes, className = '' }) {
  return <figure className={`fig ${className}`}><Photo name={name} sizes={sizes} />{caption && <figcaption>{caption}</figcaption>}</figure>
}

export function Hero({ title, lead, img, mobile, pos = 'center', children }) {
  const d = PH[img], m = PH[mobile || img]
  return (
    <section className="hero">
      <picture>
        <source media="(max-width:699px)" srcSet={srcSet(m)} sizes="100vw" />
        <img className="hero-img" src={src(d, d.w[d.w.length - 1])} srcSet={srcSet(d)} sizes="100vw" alt="" style={{ objectPosition: pos }} fetchpriority="high" decoding="async" />
      </picture>
      <div className="wrap hero-text"><h1>{title}</h1>{lead && <p className="lead">{lead}</p>}{children}</div>
    </section>
  )
}

export function Gallery({ names, label }) {
  return (
    <ul className="gallery" aria-label={label}>
      {names.map((n) => <li key={n}><Photo name={n} sizes="(min-width:1000px) 360px, 80vw" /></li>)}
    </ul>
  )
}

export const Notice = ({ children }) => <p className="notice" role="note">{children}</p>

const FIELDS = { name: 'Your name', email: 'Email address' }

export function Form({ kind, categories, messageLabel = 'Message', askName = true, askMessage = true, eventId, button = 'Send', done = 'Thank you. We have received your message.' }) {
  const [state, setState] = useState({ status: 'idle', errors: {} })
  async function submit(e) {
    e.preventDefault()
    const form = e.currentTarget
    const f = new FormData(form)
    if (f.get('website')) return setState({ status: 'sent', errors: {} }) // honeypot: bots fill this hidden field
    const v = Object.fromEntries(f)
    const errors = {}
    if (askName && !v.name?.trim()) errors.name = 'Please enter your name.'
    if (!/^\S+@\S+\.\S+$/.test(v.email || '')) errors.email = 'Please enter a valid email address.'
    if (askMessage && !v.message?.trim()) errors.message = 'Please write a short message.'
    if (!v.consent) errors.consent = 'Please agree so we can contact you.'
    if (Object.keys(errors).length) {
      setState({ status: 'invalid', errors })
      requestAnimationFrame(() => form.querySelector('[aria-invalid="true"]')?.focus())
      return
    }
    if (!backendReady) return setState({ status: 'error', errors: {} })
    setState({ status: 'sending', errors: {} })
    const { error } = await supabase.from('submissions').insert({
      kind, name: v.name?.trim() || null, email: v.email.trim(), category: v.category || null,
      message: v.message?.trim() || null, event_id: eventId || null, consent: true,
    })
    setState({ status: error ? 'error' : 'sent', errors: {} })
    if (!error) form.reset()
  }
  const { status, errors } = state
  const err = (k) => errors[k] && <span className="err" id={`${kind}-${k}-e`}>{errors[k]}</span>
  const a = (k) => ({ id: `${kind}-${k}`, name: k, 'aria-invalid': !!errors[k], 'aria-describedby': errors[k] ? `${kind}-${k}-e` : undefined })
  return (
    <form className="form" onSubmit={submit} noValidate>
      {askName && <label>{FIELDS.name}<input {...a('name')} autoComplete="name" />{err('name')}</label>}
      <label>{FIELDS.email}<input {...a('email')} type="email" autoComplete="email" />{err('email')}</label>
      {categories && <label>Topic<select {...a('category')}>{categories.map((c) => <option key={c}>{c}</option>)}</select></label>}
      {askMessage && <label>{messageLabel}<textarea {...a('message')} rows="5" maxLength="3000" />{err('message')}</label>}
      <input className="hp" name="website" tabIndex="-1" autoComplete="off" aria-hidden="true" />
      <label className="check"><input {...a('consent')} type="checkbox" value="yes" />
        <span>I agree HomeAFar may use these details to reply to me. See the <Link to="/privacy">privacy notice</Link>.</span></label>{err('consent')}
      <button className="btn" disabled={status === 'sending'}>{status === 'sending' ? 'Sending…' : button}</button>
      <p className="status" role="status" aria-live="polite">
        {status === 'sent' && done}
        {status === 'invalid' && 'Please fix the highlighted fields.'}
        {status === 'error' && 'Sorry, we could not send this right now. Please email homeafar26@gmail.com.'}
      </p>
    </form>
  )
}
